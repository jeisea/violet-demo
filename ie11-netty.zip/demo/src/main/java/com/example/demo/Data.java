package com.example.demo;

public class Data {
  public String yo;
}
