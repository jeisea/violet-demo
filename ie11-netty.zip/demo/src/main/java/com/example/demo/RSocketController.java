package com.example.demo;

import java.time.Duration;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Flux;

@Controller
public class RSocketController {

    @MessageMapping("interval-stream")
    public Flux<Long> intervalStream(Data test) {
      System.out.println(test.yo);
      return Flux.interval(Duration.ofSeconds(1));
    }


}
